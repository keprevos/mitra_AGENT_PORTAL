import { v4 as uuidv4 } from 'uuid';
import { userModel } from '../models/userModel.js';
import { bankModel } from '../models/bankModel.js';
import { agencyModel } from '../models/agencyModel.js';
import { auditService } from '../services/auditService.js';
import { emailService } from '../services/emailService.js';
import { passwordService } from '../services/passwordService.js';
import { smsService } from '../services/smsService.js';

export const bankController = {
  async registerAgent(req, res) {
    try {
      const {
        email,
        firstName,
        lastName,
        phone,
        agencyId,
      } = req.body;

      // Check if bank has permission to register agents
      const bank = await bankModel.findById(req.user.bankId);
      if (!bank.can_register_agents) {
        return res.status(403).json({
          message: 'Bank does not have permission to register agents'
        });
      }

      // Verify agency belongs to bank
      const agency = await agencyModel.findById(agencyId);
      if (!agency || agency.bank_id !== req.user.bankId) {
        return res.status(400).json({
          message: 'Invalid agency selected'
        });
      }

      const temporaryPassword = passwordService.generateTemporaryPassword();
      const hashedPassword = await passwordService.hashPassword(temporaryPassword);

      const agent = await userModel.create({
        id: uuidv4(),
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role: 'agent',
        bankId: req.user.bankId,
        agencyId,
        status: 'pending_password_reset',
        createdBy: req.user.id,
      });

      // Send credentials
      await emailService.sendWelcomeEmail(agent, temporaryPassword);
      if (phone) {
        await smsService.sendTemporaryPassword(phone, temporaryPassword);
      }

      await auditService.logAction(
        req.user.id,
        'user_created',
        'user',
        agent.id,
        {
          role: 'agent',
          bankId: req.user.bankId,
          agencyId,
        },
        req.ip
      );

      res.status(201).json({
        message: 'Agent registered successfully',
        agent: {
          id: agent.id,
          email: agent.email,
          firstName: agent.firstName,
          lastName: agent.lastName,
          agencyId: agent.agencyId,
        },
      });
    } catch (error) {
      console.error('Agent registration error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  async registerAgentStaff(req, res) {
    try {
      const {
        email,
        firstName,
        lastName,
        phone,
        agencyId,
      } = req.body;

      // Check if bank has permission to register staff
      const bank = await bankModel.findById(req.user.bankId);
      if (!bank.can_register_staff) {
        return res.status(403).json({
          message: 'Bank does not have permission to register agent staff'
        });
      }

      // Verify agency belongs to bank
      const agency = await agencyModel.findById(agencyId);
      if (!agency || agency.bank_id !== req.user.bankId) {
        return res.status(400).json({
          message: 'Invalid agency selected'
        });
      }

      const temporaryPassword = passwordService.generateTemporaryPassword();
      const hashedPassword = await passwordService.hashPassword(temporaryPassword);

      const staff = await userModel.create({
        id: uuidv4(),
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role: 'agent_staff',
        bankId: req.user.bankId,
        agencyId,
        status: 'pending_password_reset',
        createdBy: req.user.id,
      });

      // Send credentials
      await emailService.sendWelcomeEmail(staff, temporaryPassword);
      if (phone) {
        await smsService.sendTemporaryPassword(phone, temporaryPassword);
      }

      await auditService.logAction(
        req.user.id,
        'user_created',
        'user',
        staff.id,
        {
          role: 'agent_staff',
          bankId: req.user.bankId,
          agencyId,
        },
        req.ip
      );

      res.status(201).json({
        message: 'Agent staff registered successfully',
        staff: {
          id: staff.id,
          email: staff.email,
          firstName: staff.firstName,
          lastName: staff.lastName,
          agencyId: staff.agencyId,
        },
      });
    } catch (error) {
      console.error('Agent staff registration error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  async getAgents(req, res) {
    try {
      const agents = await userModel.findByBankAndRole(req.user.bankId, 'agent');
      res.json(agents);
    } catch (error) {
      console.error('Get agents error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  async getAgentStaff(req, res) {
    try {
      const staff = await userModel.findByBankAndRole(req.user.bankId, 'agent_staff');
      res.json(staff);
    } catch (error) {
      console.error('Get agent staff error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
};
